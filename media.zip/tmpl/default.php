<?php 
// No direct access
defined('_JEXEC') or die; ?>
<?php
JHtml::_('stylesheet', JUri::root() . 'media/mod_etliste/css/etliste.css');
echo $liste; ?>